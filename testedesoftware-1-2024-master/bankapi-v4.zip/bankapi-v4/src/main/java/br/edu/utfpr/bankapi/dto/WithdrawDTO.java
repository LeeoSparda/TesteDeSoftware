package br.edu.utfpr.bankapi.dto;

public record WithdrawDTO(long sourceAccountNumber, double amount) {
    
}
