package br.edu.utfpr.bankapi.model;

public enum TransactionType {
    TRANSFER,
    DEPOSIT,
    WITHDRAW;
}
